# Cookie Recipe

- We will be using the provided starter code to develop a cookie recipe using HTML alone.
- Your job is to look at the content and devise a way to display it more appealingly on the page with the tags you already know.
- To use the provided image you will have to research the `img` tag.